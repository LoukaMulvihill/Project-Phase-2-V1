/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package utils;

/**
 *
 * @author Louka
 */
public interface IConstants {
    
    public static final String USER_TYPE_ADMIN = "ADMIN";
    public static final String USER_TYPE_GENERAL = "GENUSER";
    
    public static final String SESSION_KEY_USER = "SKUSER";
    
}

